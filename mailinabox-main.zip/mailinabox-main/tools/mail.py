#!/bin/bash
# This script has moved.
management/cli.py "$@"
