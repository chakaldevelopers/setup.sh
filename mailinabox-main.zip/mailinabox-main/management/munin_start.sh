#!/bin/bash
mkdir -p /var/run/munin && chown munin /var/run/munin
